HATEVAL

This dataset is part of the SemEval 2019 task on "Multilingual detection of hate speech against immigrants and women in Twitter (hatEval)". In particular, the training set from such task is included.

In particular, this subtask consists of detecting whether a given Twitter message is hate speech (1) or not (0).

More information about the task can be found in the following reference paper:

Basile, V., Bosco, C., Fersini, E., Nozza, D., Patti, V., Pardo, F.M.R., Rosso, P. and Sanguinetti, M., 2019. Semeval-2019 task 5: Multilingual detection of hate speech against immigrants and women in twitter. In Proceedings of the 13th International Workshop on Semantic Evaluation (pp. 54-63).
https://www.aclweb.org/anthology/S19-2007/
